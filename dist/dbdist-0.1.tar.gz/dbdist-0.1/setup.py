from setuptools import setup

setup(name='dbdist',
      version='0.1',
      description='Gaussian and Normal distributions class',
      packages=['dbdist'],
      zip_safe=False)
